CREATE TABLE [dbo].[test_table_unpivot](
        [fio] [varchar](50) NULL,
        [number1] [int] NULL,
        [number2] [int] NULL,
        [number3] [int] NULL,
        [number4] [int] NULL,
        [number5] [int] NULL,
   ) 
   GO