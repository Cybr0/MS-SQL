CREATE TABLE [dbo].[test_table_pivot](
        [fio] [varchar](50) NULL,
        [god] [int] NULL,
        [summa] [float] NULL
   ) ON [PRIMARY]
   GO

